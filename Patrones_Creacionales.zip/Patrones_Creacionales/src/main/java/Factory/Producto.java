package Factory;

public interface Producto {

    void operacion();
}
