
package Prototype;


public interface ICuenta extends Cloneable{
    
    ICuenta clonar();
}
